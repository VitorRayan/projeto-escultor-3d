var indexSectionsWithContent =
{
  0: "abcgimprsvw~",
  1: "sv",
  2: "ms",
  3: "cmpsw~",
  4: "abgir"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis"
};

